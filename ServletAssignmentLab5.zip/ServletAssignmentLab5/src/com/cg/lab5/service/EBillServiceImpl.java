package com.cg.lab5.service;

import java.util.ArrayList;

import com.cg.lab5.bean.BillDetails;
import com.cg.lab5.bean.Consumers;
import com.cg.lab5.dao.*;

public class EBillServiceImpl implements IEBillService{

	IEBillDao billDao;
	public EBillServiceImpl()
	{
		billDao=new EBillDaoImpl();
	}
	@Override
	public boolean isConsumerExists(int consumerNo) {
		
		return billDao.isConsumerExists(consumerNo);
	}

	@Override
	public Consumers getConsumer(int consumerNo) {
		
		return billDao.getConsumer(consumerNo);
	}

	@Override
	public BillDetails addBillDetails(BillDetails billDetails) {
		
		return billDao.addBillDetails(billDetails);
	}


}
