package com.cg.lab5.service;



import java.util.ArrayList;

import com.cg.lab5.bean.BillDetails;
import com.cg.lab5.bean.Consumers;


public interface IEBillService {
	public boolean isConsumerExists(int consumerNo);
	public Consumers getConsumer(int consumerNo);
	public BillDetails addBillDetails(BillDetails billDetails);
	
}
