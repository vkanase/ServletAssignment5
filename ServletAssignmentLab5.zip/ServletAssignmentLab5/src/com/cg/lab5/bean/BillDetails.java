package com.cg.lab5.bean;

import java.sql.Date;

public class BillDetails {

	private int bil_num;
	private int consumer_num;
	private double cur_reading;
	private double unitsConsumed;
	private double netAmount;
	private Date billDate;
	public int getBil_num() {
		return bil_num;
	}
	public void setBil_num(int bil_num) {
		this.bil_num = bil_num;
	}
	public int getConsumer_num() {
		return consumer_num;
	}
	public void setConsumer_num(int consumer_num) {
		this.consumer_num = consumer_num;
	}
	public double getCur_reading() {
		return cur_reading;
	}
	public void setCur_reading(double cur_reading) {
		this.cur_reading = cur_reading;
	}
	public double getUnitsConsumed() {
		return unitsConsumed;
	}
	public void setUnitsConsumed(double unitsConsumed) {
		this.unitsConsumed = unitsConsumed;
	}
	public double getNetAmount() {
		return netAmount;
	}
	public void setNetAmount(double netAmount) {
		this.netAmount = netAmount;
	}
	public Date getBillDate() {
		return billDate;
	}
	public void setBillDate(Date billDate) {
		this.billDate = billDate;
	}
	public BillDetails(int bil_num, int consumer_num, double cur_reading,
			double unitsConsumed, double netAmount, Date billDate) {
		super();
		this.bil_num = bil_num;
		this.consumer_num = consumer_num;
		this.cur_reading = cur_reading;
		this.unitsConsumed = unitsConsumed;
		this.netAmount = netAmount;
		this.billDate = billDate;
	}
	public BillDetails() {
		super();
	}
	@Override
	public String toString() {
		return "BillDetails [bil_num=" + bil_num + ", consumer_num="
				+ consumer_num + ", cur_reading=" + cur_reading
				+ ", unitsConsumed=" + unitsConsumed + ", netAmount="
				+ netAmount + ", billDate=" + billDate + "]";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + bil_num;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		BillDetails other = (BillDetails) obj;
		if (bil_num != other.bil_num)
			return false;
		return true;
	}
	
	
}
