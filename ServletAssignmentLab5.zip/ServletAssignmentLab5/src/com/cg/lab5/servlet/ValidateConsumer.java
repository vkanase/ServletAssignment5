package com.cg.lab5.servlet;

import java.io.IOException;



import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.lab5.bean.Consumers;
import com.cg.lab5.service.EBillServiceImpl;
import com.cg.lab5.service.IEBillService;




@WebServlet("/ValidateConsumer")
public class ValidateConsumer extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	IEBillService billService;
    public ValidateConsumer() {
        super();
       
    }

	public void init(ServletConfig config) throws ServletException {
		
	}

	
	public void destroy() {
		
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);     
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		billService=new EBillServiceImpl();
		System.out.println("In doPost*****************");
		
		String id=request.getParameter("txtCNo");
		
		 int consumerid=Integer.parseInt(id);
		System.out.println("In Calculate Begin");
		 if(billService.isConsumerExists(consumerid))
		 {
			
			System.out.println("valid customer");
			RequestDispatcher rdUserExists=request.getRequestDispatcher("/CalculateBillServlet");
			rdUserExists.forward(request,response);
		 }
		 else
		 {
				 RequestDispatcher rdFailure=request.getRequestDispatcher("/ErrorView.html");
					rdFailure.forward(request,response);
		 }
		 	

		
	
	}

}
