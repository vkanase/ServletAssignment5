package com.cg.lab5.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.lab5.bean.BillDetails;
import com.cg.lab5.bean.Consumers;

@WebServlet("/InfoView")
public class InfoView extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public InfoView() {
        super();
       
    }


	public void init(ServletConfig config) throws ServletException {
		
	}


	public void destroy() {
		
	}


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doPost(request,response);
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter pw=response.getWriter();
		Consumers consumer=(Consumers)request.getAttribute("ConsumerObj");
		BillDetails details=(BillDetails)request.getAttribute("BillDetailsObj");
		pw.println("<b><h3>Welcome  "+consumer.getConsumer_name()+"</h3>");
		pw.println("<h1>Electricity Bill For Consumer Number-"+consumer.getConsumer_num()+" is</h1>");
		pw.println("<h3>Units Consumed :: "+details.getUnitsConsumed());
		pw.println("<br/>Net Amount :: "+details.getNetAmount()+"</h3></b>");
	}

}
