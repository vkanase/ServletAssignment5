package com.cg.lab5.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.function.Consumer;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.lab5.bean.BillDetails;
import com.cg.lab5.bean.Consumers;
import com.cg.lab5.service.EBillServiceImpl;
import com.cg.lab5.service.IEBillService;


@WebServlet("/CalculateBillServlet")
public class CalculateBill extends HttpServlet {
	private static final long serialVersionUID = 1L;
       IEBillService billService=new EBillServiceImpl();
  
    public CalculateBill() {
        super();
    }

	
	public void init(ServletConfig config) throws ServletException {
	
	}


	public void destroy() {
		
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doPost(request,response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter pw=response.getWriter();
		String consumerId= (String) request.getAttribute("ConsumerId");
		String lastReading=(String) request.getAttribute("LReading");
		String currReading=(String) request.getAttribute("CReading");
		int cid=Integer.parseInt(consumerId);
		Double lr=Double.parseDouble(lastReading);
		Double cr=Double.parseDouble(currReading);
		if(lr<cr)
		{
		Double units=cr-lr;
		
		Double bill=(units*1.15)+100;
	

		System.out.println(bill);
		BillDetails billDetails=new BillDetails();
		billDetails.setConsumer_num(cid);
		billDetails.setCur_reading(cr);
		billDetails.setUnitsConsumed(units);
		billDetails.setNetAmount(bill);
		
		
		Consumers consumer=(Consumers) billService.getConsumer(cid);              
		
		BillDetails details=billService.addBillDetails(billDetails);
		

		request.setAttribute("ConsumerObj", consumer);
		request.setAttribute("BillDetailsObj",details);
	
		RequestDispatcher rdUserExists=request.getRequestDispatcher("/InfoView");
		rdUserExists.forward(request,response);
		}
		else
		{
			pw.println("Inccorect Values In Fields");
		}
	}

}
