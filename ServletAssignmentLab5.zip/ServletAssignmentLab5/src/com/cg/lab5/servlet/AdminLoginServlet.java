package com.cg.lab5.servlet;

import java.io.IOException;
import java.io.PrintWriter;


import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/AdminLoginServlet")
public class AdminLoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

    public AdminLoginServlet() {
        super();
         }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	doPost(request,response);
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter pw=response.getWriter();
		String un=request.getParameter("txtUN");
		String pwd=request.getParameter("txtPwd");
		
		
		if(un.equalsIgnoreCase("Admin")&& pwd.equalsIgnoreCase("Admincg"))
		{
			response.sendRedirect("User_Info.html");
			
		}
		else
		{
			response.sendRedirect("Failure.html");
		}	
	}

}
