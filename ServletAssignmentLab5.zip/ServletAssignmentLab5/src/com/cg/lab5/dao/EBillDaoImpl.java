package com.cg.lab5.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;



import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;


import com.cg.lab5.bean.BillDetails;
import com.cg.lab5.bean.Consumers;
import com.cg.lab5.util.DBUtil;


public class EBillDaoImpl implements IEBillDao{

	Connection con;
	Statement st;
	PreparedStatement pst;
	ResultSet rs;
	@Override
	public boolean isConsumerExists(int consumerNo) {
		boolean flag=false;
		try{
			con=DBUtil.getConnection();
			System.out.println("In Dao");
		System.out.println("In user dao con is "+con);
		String selectQuery="SELECT COUNT(*) FROM CONSUMERS WHERE CONSUMER_NUM=?";
		
		pst=con.prepareStatement(selectQuery);
		pst.setInt(1,consumerNo);
		rs=pst.executeQuery();
		rs.next();
		int count=rs.getInt(1);
		if(count==1)
		{
			flag= true;
		}
		else
		{
			flag=false;
		}
			
		} catch (SQLException e) {
		
			e.printStackTrace();
		}
		finally{
			try{
			rs.close();
			pst.close();
			con.close();
			}
		catch (SQLException e) {
		
			e.printStackTrace();
		}
		}
		return flag;
	}

	@Override
	public Consumers getConsumer(int consumerNo) {
	
		Consumers consumer=null;
		try {
			con=DBUtil.getConnection();
	
		System.out.println("In consumer dao con is "+con);
		String selectQuery="SELECT * FROM CONSUMERS WHERE CONSUMER_NUM=?";
		
		pst=con.prepareStatement(selectQuery);
		pst.setInt(1,consumerNo);
		rs=pst.executeQuery();
		rs.next();
		consumer=new Consumers();
		consumer.setConsumer_num(rs.getInt(1));
		consumer.setConsumer_name(rs.getString(2));
		consumer.setConsumer_addr(rs.getString(3));
	}
		catch (SQLException e) {
			
			e.printStackTrace();
		}
		finally{
			try{
			rs.close();
			pst.close();
			con.close();
			}
		catch (SQLException e) {
		
			e.printStackTrace();
		}
		}
		return consumer;
	}

	@Override
	public BillDetails addBillDetails(BillDetails bill) {
	
		
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
		/*Date date = new Date();
		java.sql.Date dt= (java.sql.Date) date;*/
		long millis=System.currentTimeMillis();  
        java.sql.Date dt=new java.sql.Date(millis); 
		bill.setBillDate(dt);
	
		
		try {
			con=DBUtil.getConnection();
		
			Statement stm=con.createStatement();
			ResultSet rs=stm.executeQuery("select seq_bill_num.nextVal from dual");
			if(rs.next()==false)
				System.out.println("Something went wrong");
			int id=rs.getInt(1);
			bill.setBil_num(id);
			String insertQuery="INSERT INTO BILLDETAILS VALUES(?,?,?,?,?,?)";
			pst=con.prepareStatement(insertQuery);
			pst.setInt(1, id);
			pst.setInt(2, bill.getConsumer_num());
			pst.setDouble(3,bill.getCur_reading());
			pst.setDouble(4,bill.getUnitsConsumed());
			pst.setDouble(5, bill.getNetAmount());
			pst.setDate(6,bill.getBillDate());
			pst.execute();
			
			
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		finally{
			
			
				try {
					pst.close();
					con.close();
				} catch (SQLException e) {
					
					e.printStackTrace();
				}
			
		}
		return bill;
	}



	
}
