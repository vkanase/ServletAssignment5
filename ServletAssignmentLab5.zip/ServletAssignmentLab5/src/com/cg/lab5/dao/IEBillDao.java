package com.cg.lab5.dao;



import com.cg.lab5.bean.BillDetails;
import com.cg.lab5.bean.Consumers;

public interface IEBillDao {

	public boolean isConsumerExists(int consumerNo);
	public Consumers getConsumer(int consumerNo);
	public BillDetails addBillDetails(BillDetails billDetails);
	
}
