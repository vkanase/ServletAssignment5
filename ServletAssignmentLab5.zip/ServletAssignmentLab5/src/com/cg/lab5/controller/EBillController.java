package com.cg.lab5.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.lab5.service.EBillServiceImpl;
import com.cg.lab5.service.IEBillService;


@WebServlet("/EBillController")
public class EBillController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	ServletConfig  conf;
	IEBillService service=new EBillServiceImpl();
    public EBillController() {
        super();
      
    }


	public void init(ServletConfig config) throws ServletException {
	
	}

	
	public void destroy() {
	
	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		doPost(request,response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
System.out.println("In doPost() Controller");
		
		String action=request.getParameter("action");
		System.out.println(action);
		if(action!=null)
		{
			if(action.equals("AdminLogin"))
			{
				RequestDispatcher rdLog=request.getRequestDispatcher("/AdminLoginServlet");
				rdLog.forward(request,response);
			}
			if(action.equals("ValidateConsumer"))
			{
				System.out.println("In validateConsumer");
				String cid=request.getParameter("txtCNo");
				String currReading=request.getParameter("cMReading");
				String lastReading=request.getParameter("lMReading");
				
				request.setAttribute("ConsumerId", cid);
				request.setAttribute("CReading",currReading);
				request.setAttribute("LReading",lastReading);
				RequestDispatcher rdVal=request.getRequestDispatcher("/ValidateConsumer");
				
				rdVal.forward(request,response);
				System.out.println("Finish validateConsumer");
			}
			
			
		}
	}

}
